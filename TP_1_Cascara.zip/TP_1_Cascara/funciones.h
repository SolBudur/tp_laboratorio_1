#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
float suma(float el_numero1, float el_numero2);
float resta(float el_numero1, float el_numero2);
float division(float el_numero1, float el_numero2);
float multiplicacion(float el_numero1, float el_numero2);
long long int factorial(int el_numero1);
int validarElFactorial(float el_numero1);
#endif // FUNCIONES_H_INCLUDED
